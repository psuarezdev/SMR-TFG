import '../../theme/Login.css';
import { useState } from 'react';
import { Redirect } from 'react-router';
import { url } from '../../global/global';
import useAuth from '../../hooks/useAuth';
import useForm from '../../hooks/useForm';
import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';

const Login = () => {

  const { form, changed } = useForm({});
  const [logged, setLogged] = useState("not_logged");
  const { auth, setAuth } = useAuth();

  const loginUsuario = async (e) => {
    e.preventDefault();
    let usuarioALoggear = form;

    const request = await fetch(`http://${url}/usuario/login`, {
      method: "POST",
      body: JSON.stringify(usuarioALoggear),
      headers: {
        "Content-Type": "application/json"
      }
    });

    const data = await request.json();

    if (data.status === "success") {
      localStorage.setItem('usuario', JSON.stringify(data.usuario));

      setLogged("logged");
      setAuth(data.usuario);
      if (Object.keys(auth).length > 0) {
        window.location.href = "/";
      }
    } else {
      setLogged("error");
    }
  };

  return (
    Object.keys(auth).length <= 0 ? (
      <IonPage>
        <IonHeader>
          <IonToolbar>
            <IonTitle>Login</IonTitle>
          </IonToolbar>
        </IonHeader>
        <IonContent fullscreen>
          <IonHeader collapse="condense">
            <IonToolbar>
              <IonTitle size="large">Login</IonTitle>
            </IonToolbar>
          </IonHeader>
          <section className="layout__content">
            <div className="login">
              <form onSubmit={loginUsuario}>
                {
                  logged === "error" ? (
                    <div className="alert alert-danger alert-dismissible fade show" role="alert">
                      <strong>Error al identificar usuario</strong>
                      <span className="btn-close" onClick={() => setLogged("not_logged")} aria-label="Close">X</span>
                    </div>
                  ) : ""
                }
                <label htmlFor="nombre">Usuario</label>
                <input type="text" name="nombre" onChange={changed} placeholder="Usuario" autoComplete="off" pattern="[a-zA-Z]+" required />
                <label htmlFor="password">Contraseña</label>
                <input type="password" name="password" onChange={changed} placeholder="Contraseña" autoComplete="off" pattern="^[a-zA-Z0-9.\s]+$" required />
                <button type="submit" style={{ backgroundColor: "rgb(75, 188, 75)", color: "white", marginTop: "2rem" }}>
                  Acceder
                </button>
              </form>
            </div>
          </section>
        </IonContent>
      </IonPage>
    ) : <Redirect to="/" />
  );
};

export default Login;