import { IonHeader, IonToolbar } from "@ionic/react";
import { useEffect, useState } from "react";
import { Redirect, useParams } from "react-router";
import { url } from "../../global/global";
import { Button, Form } from "react-bootstrap";
import { Link } from "react-router-dom";
import useAuth from "../../hooks/useAuth";

const Editar = ({ todosSensores, setTodosSensores }) => {

  const { auth } = useAuth();
  const params = useParams();
  const [sensor, setSensor] = useState({});

  const getProducto = async (sensor_id) => {
    const data = await fetch(`http://${url}/sensor/${sensor_id}`);
    const { sensor } = await data.json();

    if (Object.keys(sensor).length > 0) {
      setSensor(sensor);
    }
  };

  const editar = async (e) => {
    e.preventDefault();

    let data = {
      nombre: e.target.nombre.value,
      valor: e.target.valor.value
    };

    if (data.nombre.length > 0 && data.valor.length > 0) {
      const payload = await fetch(`http://${url}/sensor/editar/${sensor.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          nombre: data.nombre,
          valor: data.valor
        })
      });

      const dataFetched = await payload.json();

      if (dataFetched.status === "success") {
        let sensoresFiltrados = todosSensores.filter(sensor => sensor.id !== dataFetched.sensor.id);

        setTodosSensores([...sensoresFiltrados, dataFetched.sensor]);
      }
    }
  };

  useEffect(() => {
    getProducto(params.id);
  }, []);

  return (
    <>
      <IonHeader>
        <IonToolbar class="px-3" style={{ padding: "0px 20px", fontSize: "20px", fontWeight: "500", letterSpacing: "0.0125em" }}>
          Editar componente
        </IonToolbar>
      </IonHeader>
      {
        Object.keys(sensor).length > 0 ? (
          <Form className="p-3" onSubmit={e => editar(e)}>
            <Form.Group className="mb-3" controlId="formBasicEmail">
              <Form.Label className="text-light">Nombre</Form.Label>
              <Form.Control className="bg-dark text-light border-0 shadow-none" type="text" name="nombre" defaultValue={sensor.nombre} pattern="[a-zA-z0-9\- ]+" required />
            </Form.Group>
            <Form.Group className="mb-3" controlId="formBasicPassword">
              <Form.Label className="text-light">Valor</Form.Label>
              <Form.Control className="bg-dark text-light border-0 shadow-none" type="text" name="valor" defaultValue={sensor.valor} pattern="^[0-9.\s]+$" required />
            </Form.Group>
            <Form.Group className="d-flex justify-content-center gap-3">
              <Button variant="primary" type="submit">
                Guardar
              </Button>
              <Button variant="danger" type="reset">
                <Link className="text-decoration-none text-light" to="/sensores">Cancelar</Link>
              </Button>
            </Form.Group>
          </Form>
        ) : (
          <div className="text-center text-light p-3">
            <h1>Error 500</h1>
            <h3>Valor de sensor no encontrado</h3>
          </div>
        )
      }
    </>
  );
};

export default Editar;