import { IonContent, IonHeader, IonPage, IonTitle, IonToolbar } from '@ionic/react';
import { useEffect, useState } from 'react';
import { url } from '../../global/global';
import { Button, Dropdown } from 'react-bootstrap';
import '../../theme/Componentes.css';
import useAuth from '../../hooks/useAuth';
import { Redirect } from 'react-router';

const Sensores = ({ categorias, setCategorias, todosSensores, setTodosSensores }) => {

  const { auth } = useAuth();
  const todasCategorias = JSON.parse(localStorage.getItem("categorias"));
  const [sensores, setSensores] = useState([]);
  const [filtroCat, setFiltroCat] = useState("Filtrar categorias");

  const filtrarCategoria = (nombre_categoria, categoria_id = null) => {
    if (nombre_categoria === "Filtrar categorias") {
      setSensores(todosSensores);
      setCategorias(todasCategorias);
      setFiltroCat("Filtrar categorias");
      return true;
    }

    let sensores_filtrados = todosSensores.filter(sensor => sensor.categoriaId === categoria_id);

    if (sensores.length > 0 && sensores_filtrados.length > 0) {
      setSensores(sensores_filtrados);
      setFiltroCat(nombre_categoria);
    }
  };

  const borrar = async (sensor_id) => {
    const sensor_eliminado = await fetch(`http://${url}/sensor/borrar/${sensor_id}`, { method: "DELETE" })
    const dataFetched = await sensor_eliminado.json();
    if (dataFetched.status === "success") {
      let nuevoListadoSens = todosSensores.filter(sensor => sensor.id !== dataFetched.sensor.id);
      setTodosSensores(nuevoListadoSens);
    }
  };

  useEffect(() => {
    setSensores(todosSensores);
  }, [todosSensores]);

  return (
    Object.keys(auth).length > 0 ? (
    <IonPage>
      <IonHeader>
        <IonToolbar>
          <IonTitle>Sensores</IonTitle> 
        </IonToolbar>
      </IonHeader>
      <IonContent fullscreen>
        <IonHeader collapse="condense">
          <IonToolbar>
            <IonTitle size="large">Sensores</IonTitle>
          </IonToolbar>
        </IonHeader>
        <div className="d-flex flex-wrap justify-content-center gap-2">
          <Dropdown className="d-flex justify-content-center my-3">
            <Dropdown.Toggle className="btn-violet border-0" id="dropdown-basic" style={{ width: "160px" }}>
              {filtroCat}
            </Dropdown.Toggle>
            <Dropdown.Menu className="flex-column justify-content-center align-items-center">
              <ul className="m-0 p-0">
                {
                  categorias?.length > 0 &&
                  categorias?.map(categoria => {
                    return (
                      <li
                        className="dropdown-item user-select-none" key={categoria.id}
                        onClick={() => filtrarCategoria(categoria.nombre, categoria.id)}
                      >
                        {categoria.nombre}
                      </li>
                    );
                  })
                }
                {
                  filtroCat !== "Filtrar categorias" ? (
                    <li
                      className="dropdown-item user-select-none" key="default"
                      onClick={() => filtrarCategoria("Filtrar categorias")}
                    >
                      Filtrar categorias
                    </li>
                  ) : false
                }
              </ul>
            </Dropdown.Menu>
          </Dropdown>
        </div>
        <table className="styled__table">
          <thead>
            <tr>
              <th>Nombre</th>
              <th>Valor</th>
              <th>Gestionar</th>
            </tr>
          </thead>
          <tbody>
            {
              sensores.length > 0 &&
              sensores.map(sensor => {
                return (
                  <tr className="active-row" key={sensor.id}>
                    <td>{sensor.nombre}</td>
                    <td>{sensor.valor}</td>
                    <td>
                      <a href={`/editar/${sensor.id}`} className="btn btn-primary text-text-decoration-none mb-3">Editar</a>
                      <br />
                      <Button variant="danger" onClick={() => borrar(sensor.id)}>
                        Borrar
                      </Button>
                    </td>
                  </tr>
                );
              })
            }
          </tbody>
        </table>
      </IonContent>
    </IonPage >
    ) : <Redirect to="login" />
  );
};

export default Sensores;