const url = "192.168.1.33:3900/api/v1";

module.exports = {
  url
}