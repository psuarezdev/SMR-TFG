const url = "192.168.1.81:3900/api/v1";

module.exports = {
  url
}