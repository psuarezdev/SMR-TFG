const express = require('express')
const cors = require('cors');
const app = express();
const PORT = 3900;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors());

const usuario = require('./routes/usuario');
const categoria = require('./routes/categoria');
const sensor = require('./routes/sensor');

app.use('/api/v1/usuario', usuario);
app.use('/api/v1/categoria', categoria);
app.use('/api/v1/sensor', sensor);

app.listen(PORT, () => {
  console.log(`Servidor corriendo en el puerto ${PORT}`);
});