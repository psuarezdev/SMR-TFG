module.exports = (sequelize, DataTypes) => {
  const Sensor = sequelize.define('sensores', {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true
    },
    nombre: {
      type: DataTypes.STRING,
      allowNull: false
    },
    categoriaId: {
      type: DataTypes.INTEGER,
      references: {
        model: 'categorias',
        key: 'id'
      },
      allowNull: false
    },
    valor: {
      type: DataTypes.FLOAT,
      allowNull: false
    }
  });
  
  return Sensor;
}