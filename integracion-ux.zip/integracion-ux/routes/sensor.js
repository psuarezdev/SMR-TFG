const express = require('express');
const router = express.Router();
const SensorController = require('../controllers/SensorController');

router.get('/todos', SensorController.todos);
router.get('/:id', SensorController.uno);
router.post('/agregar', SensorController.agregar);
router.put('/editar/:id', SensorController.editar);
router.delete('/borrar/:id', SensorController.borrar);

module.exports = router;