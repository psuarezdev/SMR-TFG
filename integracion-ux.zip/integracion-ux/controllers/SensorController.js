const db = require('../models/models');
const Sensor = db.sensor;
const fechaSQL = require('../services/date');

const todos = async (req, res) => {
  let sensores = await Sensor.findAll();

  if (sensores.length <= 0) {
    return res.status(500).json({
      status: 'error',
      message: 'No se han encontrado valores de sensores'
    });
  }

  return res.status(200).json({
    status: 'success',
    message: 'Sensores',
    sensores
  });
};

const uno = async (req, res) => {
  let sensor_id = req.params.id;
  let { dataValues } = await Sensor.findByPk(sensor_id);

  if (Object.keys(dataValues).length <= 0) {
    return res.status(200).json({
      status: 'error',
      message: 'No se ha encontrado el valor del sensor'
    });
  }

  return res.status(200).json({
    status: 'success',
    message: `Valor de Sensor ${sensor_id}`,
    sensor: dataValues
  });
};

const agregar = async(req, res) => {

  const { aire, ruido } = req.body;

  if(typeof aire !== "number" && typeof ruido !== "number") {
    return res.status(400).json({
      status: 'error',
      message: 'Faltan valores'
    });
  }

  const valorAire = await Sensor.create({
    id: null,
    categoriaId: 1, // Calidad del aire
    nombre: 'Aire',
    valor: aire,
    createdAt: fechaSQL,
    updatedAt: fechaSQL
  });

  const valorRuido = await Sensor.create({
    id: null,
    categoriaId: 2, // Contaminación acústica
    nombre: 'Ruido',
    valor: ruido,
    createdAt: fechaSQL,
    updatedAt: fechaSQL
  });

  return res.status(200).json({
    status: 'success',
    message: 'Probando las peticiones con arduino',
    aire: valorAire,
    ruido: valorRuido
  });
};

const editar = async (req, res) => {
  let sensor_id = req.params.id;
  let { nombre, valor } = req.body;

  if (sensor_id.length > 0 && nombre.length > 0 && valor.length > 0) {
    try {
      const sensor = await Sensor.update({
        nombre,
        valor,
      }, {
        where: { id: sensor_id }
      });

      console.log(sensor);

      return res.status(200).json({
        status: 'success',
        message: 'Valor del sensor actualizado exitosamente',
        sensor: {
          id: parseInt(sensor_id),
          nombre, 
          valor: parseInt(valor)
        }
      });
    } catch (error) { console.log(error); }
  } else {
    return res.status(500).json({
      status: 'error',
      message: 'No se ha podido actualizar el valor del sensor'
    });
  }
};

const borrar = async (req, res) => {
  let sensor_id = req.params.id;

  if (sensor_id.length > 0) {
    try {
      const { dataValues } = await Sensor.findByPk(sensor_id);

      if (Object.keys(dataValues).length > 0) {
        const sensor = await Sensor.destroy({where: { id: sensor_id }});

        return res.status(200).json({
          status: 'success',
          message: 'Valor de Sensor borrado exitosamente',
          sensor: dataValues
        });
      }
    } catch (error) { console.log(error); }
  } else {
    return res.status(500).json({
      status: 'error',
      message: 'No se ha podido borrar el valor del sensor'
    });
  }
};

module.exports = {
  todos,
  uno,
  agregar,
  editar,
  borrar
}